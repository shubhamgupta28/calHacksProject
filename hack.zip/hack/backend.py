from flask import Flask, request, send_from_directory
import requests,json
from bs4 import BeautifulSoup
from urllib.request import urlopen
import http.client, urllib.request, urllib.parse, urllib.error, base64


urls = []
news_title=[]
news_desc=[]
sentiments=[]
########### Python 3.2 #############
def newsfetch(title):
    headers = {
        # Request headers
        'Ocp-Apim-Subscription-Key': 'b5e46e8f5b574a4094285d3f6d7fc7c9',
    }

    params = urllib.parse.urlencode({
        # Request parameters
        'Category':'business',
        'Accept':'application/json',
        'q':'nasdaq:'+title,
        'count': '10',
        'offset': '0',
        'mkt': 'en-us',
        'freshness':'week',
    })

    try:
        news_title.clear()
        news_desc.clear()
        urls.clear()
        conn = http.client.HTTPSConnection('api.cognitive.microsoft.com')
        conn.request("GET", "/bing/v5.0/news/search/?%s" % params, "{body}", headers)
        response = conn.getresponse()
        data = response.read()
        k=data.decode('UTF-8')
        print(k)
        news=json.loads(k)['value']
        for new in news:
            urls.append(new['url'])
            news_title.append(new['name'])
            news_desc.append(new['description'])
        # print(urls)
        conn.close()
    except Exception as e:
        print("[Errno {0}] {1}".format(e.errno, e.strerror))
    return
    ###################################

def sentiment(word):
    data = {
        "documents": [
        {
          "language": "en",
          "id": "string",
          "text": word
        }
      ]
    }
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Ocp-Apim-Subscription-Key': '38b35de482fe4fea896bc8a4138c7324'}

    r = requests.post(
        'https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/sentiment',
        data=json.dumps(data),
        headers=headers
        )
    return json.loads(r.text)['documents'][0]['score']

def fetchKey():
    sentiments.clear()
    for u in urls:
        # print(u)
        try:
            soup=BeautifulSoup(urlopen(u),"html.parser")
            arr=[]
            for link in soup.find_all('p'):
                if link.string is not None:
                    arr.append(link.string)
            print(arr)
            data = {
                "documents": [
                    {
                        "language": "en",
                        "id": "string",
                        "text": str(arr)
                    }
                ]
            }
            headers = {'Content-Type': 'application/json', 'Accept': 'application/json',
                       'Ocp-Apim-Subscription-Key': '38b35de482fe4fea896bc8a4138c7324'}

            r = requests.post(
                'https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/sentiment',
                data=json.dumps(data),
                headers=headers
            )
            sentiments.append(json.loads(r.text)['documents'][0]['score']-0.5)
            print("_________________________________")
        except:
            sentiments.append(0)






app = Flask(__name__, static_url_path='')

@app.route('/js/<path:path>')
def send_js(path):
    return send_from_directory('js',path)

@app.route('/css/<path:path>')
def send_css(path):
    return send_from_directory('css',path)

@app.route('/img/<path:path>')
def img(path):
    return send_from_directory('img',path)

@app.route("/")
def hello():
    return "Hello World!"


@app.route('/user', methods=['GET','POST'])
def my_form_post():
    global done
    if request.method == "GET":

        result=[]
        text = request.args.get('key')
        newsfetch(text)
        fetchKey()
        result=[]
        graph=[]
        count=0
        total=0
        result.clear()
        for i in range(0, len(urls)):
            if sentiments[i] is not 0:
                result.append({"name":news_title[i],"value":sentiments[i]})
                graph.append({"title":news_title[i],"desc":news_desc[i],"score":sentiments[i]})
                total+=sentiments[i]
                count+=1
        future=total/count
        done=True
        return json.dumps({'res':result,'news':graph,'future':future})


@app.route('/info')
def info():
   text = request.args.get('key')
   import urllib.request
   url='http://dev.markitondemand.com/MODApis/Api/v2/Quote/json?symbol='+text
   data = urllib.request.urlopen(url).read()
   k = data.decode('UTF-8')
   l=json.loads(k)
   return json.dumps(l)


@app.route('/graph')
def graph():
    text = request.args.get('key')
    import urllib.request
    url='http://dev.markitondemand.com/MODApis/Api/v2/InteractiveChart/json?parameters=%7b%22Normalized%22:false,%22NumberOfDays%22:1095,%22DataPeriod%22:%22Day%22,%22Elements%22:%5b%7b%22Symbol%22:%22'+text+'%22,%22Type%22:%22price%22,%22Params%22:%5b%22ohlc%22%5d%7d%5d%7d'
    data=urllib.request.urlopen(url).read()
    k = data.decode('UTF-8')
    return json.dumps(k)

@app.route('/title')
def title():
    text = request.args.get('key')
    import urllib.request
    url='http://dev.markitondemand.com/MODApis/Api/v2/Lookup/json?input='+text
    data = urllib.request.urlopen(url).read()
    k = data.decode('UTF-8')
    l=json.loads(k)
    print(l)
    return json.dumps(l)

@app.route('/dash')
def root():
    return app.send_static_file('index.html')

if __name__ == "__main__":
    app.run(debug=True)

